# ဆိုင်စာရင်းရှင်း PRO — Myanmar Small Business Manager

**Version 1.0.3 | Release-candidate source package**

A Burmese-language, offline-first single-device shop-management app intended for small retail shops.

## Included
- Responsive web/PWA interface
- Product catalogue, cost/selling prices, stock and low-stock indicator
- Sale entry with stock deduction and gross-profit estimate
- Customer debt ledger and repayment entry
- Expense ledger, summary reports and CSV export
- Local JSON backup and restore
- Express + SQLite REST API starter with bcrypt password hashing and JWT authentication
- Separate API-based admin summary page
- Capacitor Android wrapper configuration
- One canonical GitHub Actions workflow for a **debug/test APK**
- Burmese sales advertisement, handover checklist and ownership-transfer agreement draft

## Exact product status — read before sale
This package is **not yet a finished commercial release**. The customer-facing app currently stores its business records in that browser/device's local storage. The API and admin page are separate and are **not yet wired into the app's data flow**. Therefore:
- Do not advertise cloud sync, multi-device synchronization, or a live remote admin console.
- Do not promise that browser data automatically appears in the API/admin dashboard.
- The APK workflow produces a debug APK for testing, not a signed Play Store/production APK.
- No live hosting, domain, Play Store listing, WavePay integration, payment verification, multi-tenant accounts, staff roles, printer integration, or tax compliance is included.
- Data is stored locally on the device. Users must export backups and protect the device. Test restore before using real business records.

## Run the local web app
Requirements: Node.js 20+ and npm.

```bash
npm install
npm run check
npm start
```

Open `http://localhost:3000`. The health endpoint is `/api/health`.

## Build a test Android APK with GitHub Actions
1. Create a **new private repository** on GitHub. Do not overwrite any unrelated repository.
2. Upload the contents of this project folder to the repository root (so `package.json`, `public/`, `server/`, and `.github/` are at the root).
3. Open **Actions** and allow workflows if GitHub asks.
4. Run **Build Android APK** using **Run workflow**, or push to `main` / `master`.
5. Open the completed workflow run and download the `saing-sarinn-shin-pro-debug-apk` artifact.
6. Install only for testing. A production sale requires a signed release APK/AAB and a signing key managed under a written handover process.

## Backend deployment security
The API is a starter implementation and requires independent deployment and security review before public use.
- Set `NODE_ENV=production`.
- Set a strong `ADMIN_PASSWORD`.
- Set `JWT_SECRET` to a random secret of at least 32 characters.
- Set `ADMIN_USER` as desired.
- Use HTTPS, firewall rules, database backups, rate limiting, monitoring and restore tests.
- Never commit `.env`, database files, tokens, passwords, payment credentials or Android signing keys.
- The API database must not be exposed as a public static file.
- Review CORS, authorization, validation, backup and recovery behavior before internet exposure.

## Commercial handover
A one-time sale is possible only after a buyer has tested and accepted the exact deliverables. The agreement draft is not legal advice. Have a Myanmar-qualified lawyer review it. List:
- exact source archive and version/hash;
- whether the deliverable is offline single-device only or includes a separately deployed backend;
- whether a signed APK/AAB and signing-key transfer are included;
- hosting/domain/account ownership and renewal fees, if any;
- support period, bug-fix obligations, acceptance tests and payment milestones;
- third-party dependencies and their licenses (those are not exclusively owned by the seller).

## Release checklist
See `docs/RELEASE-CHECKLIST.md`. Do not call this production-ready until every applicable item has been tested and documented.
