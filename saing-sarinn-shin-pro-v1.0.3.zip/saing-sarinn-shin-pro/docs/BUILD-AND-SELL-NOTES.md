# Build and sale notes

## Current build status
- The web/PWA front end is offline-first and stores records in the current browser/device local storage.
- The Express + SQLite API and admin summary page are separate starter components. The front-end screens do not yet synchronize with this API.
- GitHub Actions produces a debug APK for device testing. It is not a signed Play Store/release APK.

## Before a customer demo
1. Test product creation, stock changes, sales, debt and partial repayment, expenses, CSV export, backup and restore on a real Android phone.
2. Test airplane-mode launch and confirm the app never shows stale API pages for offline API calls.
3. Use a unique shop dataset; clear demo data before handing the app to a buyer.
4. If deploying the API, set `NODE_ENV=production`, a unique `ADMIN_PASSWORD`, and a random `JWT_SECRET` of at least 32 characters. Use HTTPS and persistent storage for the SQLite database.
5. Create a signed Android release only with a keystore controlled by the buyer or transferred using a secure process.
6. Have the buyer review the source, dependency licenses, backup/restore process, and ownership-transfer agreement before payment.

## Not included / not to advertise yet
- Cloud sync between devices, automatic payment verification, WavePay, staff roles, receipt printer, or multi-shop tenancy.
- Production-grade monitoring, automated remote backups, or an independently audited security review.
