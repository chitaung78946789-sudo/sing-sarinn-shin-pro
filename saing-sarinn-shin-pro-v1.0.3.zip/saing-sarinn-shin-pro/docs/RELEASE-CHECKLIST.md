# Release and buyer acceptance checklist

## Product behavior
- [ ] Test on at least two Android screen sizes and a desktop browser.
- [ ] Add/edit/delete products; test duplicate names and zero/negative values.
- [ ] Make sales; verify stock deduction, totals and gross profit.
- [ ] Test insufficient stock and invalid quantities.
- [ ] Add customer debt; record partial/full repayments; verify balances.
- [ ] Add expenses; verify report totals and date boundaries.
- [ ] Export CSV and open it in a spreadsheet.
- [ ] Export JSON backup; clear test data; restore backup; compare all records.
- [ ] Test offline use and browser/app restart.
- [ ] Test data loss/reinstall scenarios and explain backup responsibility to buyer.

## Backend and admin (not yet integrated)
- [ ] Deploy API to HTTPS hosting with production secrets.
- [ ] Verify login, token expiry, unauthorized access and input validation.
- [ ] Verify admin dashboard against real API data.
- [ ] Integrate customer app data flow with API and test conflict/retry behavior before advertising sync.
- [ ] Configure database backup, restore and monitoring.
- [ ] Security review and penetration testing before public internet exposure.

## Android distribution
- [ ] Build debug APK using GitHub Actions and install-test it.
- [ ] Create signed release APK/AAB using buyer-approved signing ownership.
- [ ] Test install, update, uninstall/reinstall and backup/restore behavior.
- [ ] Record package ID, version, build number and SHA-256 hash.

## Sale and handover
- [ ] Buyer receives demo and runs acceptance tests.
- [ ] Written agreement lists included and excluded deliverables.
- [ ] Third-party libraries and license notices disclosed.
- [ ] Payment, support window, bug-fix scope and refund/acceptance terms agreed.
- [ ] Transfer only accounts/keys explicitly listed in agreement.
- [ ] Never hand over personal passwords or unrelated accounts.
